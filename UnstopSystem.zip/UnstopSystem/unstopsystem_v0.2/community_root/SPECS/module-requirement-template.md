# module-requirement-template.md v0.2

---

# ■ミーム定義

## meme_id
（意味識別子）

## intent
（何を達成したいか）

## purpose
（なぜそれを行うか）

## scope
（適用範囲・前提条件）

## constraints
（一般化された制約）

## risks
（一般化された危険条件）

---

# ■入力定義

## input
（抽象化された入力）

---

# ■出力定義

## output
（期待される結果）

---

# ■行動制約

## prohibited_uses
（禁止用途）

## warnings
（警告）

---

# ■評価基準

## evaluation
（適合判定基準）

---

# ■実装定義（モジュール）

## module_id
（モジュール識別子）

## version_id
（バージョン）

## category
（カテゴリ）

## domain
（領域）

## implementation
（処理内容の概要）

---

# ■対応関係

## mapped_meme
（対応ミームID）

---

# ■検証

## validation_notes
（検証観点・確認事項）

---

# ■公開制御

## visibility
（公開 / 制限公開 / 非公開 / ローカル）

---

# ■メタ情報

## content_hash
（内容ハッシュ）

## signature
（署名）

---

# ■原則

・ミームを先に定義する  
・ミーム未定義のモジュールは禁止  
・1モジュール＝1ミームとする  
・個別事情は含めない  
・抽象化された形で記述する  

---

# ■定義

本テンプレートは、  
意味（ミーム）とその実装（モジュール）を  
一体として定義するための最小構造である。  

---