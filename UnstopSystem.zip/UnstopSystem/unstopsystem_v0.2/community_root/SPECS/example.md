# example.md v0.2

---

# ■ミーム定義

## meme_id
meme_generate_formal_request_document

## intent
要求内容を整理し、第三者に提示可能な形式へ変換する

## purpose
曖昧な要求や非整理状態の情報を、実行可能な形へ変換するため

## scope
・文章による要求提示  
・業務・手続き・申請・依頼などに適用可能  

## constraints
・個別事情は含めない  
・事実と推定を分離する  
・再利用可能な形式で出力する  

## risks
・不正確な情報に基づく誤変換  
・過剰な一般化による意味欠損  

---

# ■入力定義

## input
・自然言語で記述された未整理の要求  
・断片的または曖昧な情報  

---

# ■出力定義

## output
・構造化された要求文書  
・第三者が理解可能な形式  

---

# ■行動制約

## prohibited_uses
・虚偽情報の正当化  
・違法行為の支援  

## warnings
・入力内容の正確性は保証されない  
・最終確認は実行主体が行う必要がある  

---

# ■評価基準

## evaluation
・意図が正しく反映されていること  
・不要情報が含まれていないこと  
・第三者が理解可能であること  

---

# ■実装定義（モジュール）

## module_id
module_format_request_document_v1

## version_id
v1.0.0

## category
text_processing

## domain
general_documentation

## implementation
入力された要求を解析し、目的・条件・出力形式を明確化した上で、構造化された文章へ変換する  

---

# ■対応関係

## mapped_meme
meme_generate_formal_request_document

---

# ■検証

## validation_notes
・意図と出力の一致確認  
・過剰な情報削除がないか確認  
・個別事情の混入確認  

---

# ■公開制御

## visibility
public  

---

# ■メタ情報

## content_hash
（生成時に付与）

## signature
（署名情報）

---

# ■補足

本例は、  
曖昧な要求を第三者が利用可能な形式へ変換するための  
最小構成のミームおよび実装例である。  

---