# published

## 日本語
ここには、検証済みで共有可能なモジュール要求書を置く。  
他者が参照・再利用できる状態であることを前提とする。

## English
This directory contains validated and shareable module specifications.  
They are intended for reference and reuse by others.
