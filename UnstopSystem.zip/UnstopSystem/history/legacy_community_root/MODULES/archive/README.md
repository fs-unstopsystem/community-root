# archive

## 日本語
ここには、廃止または旧版のモジュール要求書を保管する。  
現在は使用しないが、履歴として保持する。

## English
This directory stores deprecated or older versions of module specifications.  
They are not active but are kept for historical reference.