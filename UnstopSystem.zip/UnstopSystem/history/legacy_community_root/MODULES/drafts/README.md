# drafts

## 日本語
ここには、未確定のモジュール要求書を置く。  
抽象化済みだが、検証・改善途中のものを含む。  
完成していなくてもよいが、共有可能な形式である必要がある。

## English
This directory contains draft module specifications.  
They are abstracted but not yet validated or finalized.  
Incomplete content is allowed, but it must be shareable in structured form.
