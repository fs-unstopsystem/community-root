# validation rules

## purpose

公開前に何を確認するかを決める。

## check points

### 1. structure
- 何の部品か分かるか
- 入力があるか
- 出力があるか
- 制約があるか

### 2. masking
- 個別事情が残っていないか
- 固有名詞が残っていないか
- 再特定の危険が高くないか

### 3. safety
- 禁止用途があるか
- 警告があるか
- 危険な使い方を防げるか

### 4. reuse
- 一回限りの話で終わっていないか
- 別の場面でも使えるか
- タグで探せるか

### 5. trace
- module_id があるか
- version_id があるか
- hash があるか
- signature があるか

## result

- PASS
  - そのまま進める
- FIX
  - 少し直して進める
- HOLD
  - まだ公開しない
- REJECT
  - 構造が壊れているか、危険

validation rules

purpose

Define what must be verified before publication.

⸻

check points

1. structure
	•	It is clear what kind of component it is
	•	Input is defined
	•	Output is defined
	•	Constraints are defined

⸻

2. masking
	•	No individual-specific information remains
	•	No proper nouns remain
	•	Risk of re-identification is sufficiently low

⸻

3. safety
	•	Prohibited use is defined
	•	Warnings are defined
	•	Risky or dangerous usage is adequately mitigated

⸻

4. reuse
	•	Not limited to a one-time case
	•	Usable in other contexts
	•	Discoverable via tags

⸻

5. trace
	•	module_id is present
	•	version_id is present
	•	content_hash is present
	•	signature is present

⸻

result
	•	PASS
	•	Proceed as is
	•	FIX
	•	Revise and proceed
	•	HOLD
	•	Do not publish yet
	•	REJECT
	•	Structure is broken or unsafe