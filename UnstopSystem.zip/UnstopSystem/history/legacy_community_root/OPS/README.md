# OPS

このフォルダは運用ルールを置く場所。

ここで決めるのは次の3つだけ。

- 何を隠すか
- 何を公開してよいか
- 何を確認してから公開するか

## files

- masking-rules.md
  - 隠す情報のルール
- publish-rules.md
  - 公開のルール
- validation-rules.md
  - 確認のルール

## basic idea

UNSTOP_SYSTEM では、
個別事情そのものではなく、
再利用できる構造だけを共有する。

そのために、

- まず隠す
- 次に整理する
- 最後に確認して公開する

という順番で扱う。

OPS

purpose

This folder defines operational rules.

Only the following three are defined here:
	•	What must be hidden
	•	What may be published
	•	What must be verified before publishing

⸻

files
	•	masking-rules.md
	•	Rules for information that must be hidden
	•	publish-rules.md
	•	Rules for publication
	•	validation-rules.md
	•	Rules for verification

⸻

basic idea

In UNSTOP_SYSTEM,
what is shared is not individual cases,
but reusable structures.

For that purpose:
	•	First, hide
	•	Then, organize
	•	Finally, verify and publish

These steps must be followed in order.
