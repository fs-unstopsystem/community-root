# publish rules

## purpose

draft から published に上げる条件を決める。

## states

- drafts
  - 作成中
- published
  - 公開可能
- archive
  - 古い版、置き換え済み、保存用

## publish conditions

published に上げるには次が必要。

- masking rules を満たしている
- validation rules を満たしている
- 必須項目が埋まっている
- 単体で読んで意味が分かる
- 禁止用途がある
- 警告がある
- module_id がある
- version_id がある
- content_hash がある
- signature がある

## archive conditions

次は archive に移す。

- 新版に置き換えた
- 危険が見つかった
- 現行では使わない
- 履歴として残したい

## note

公開は使用保証ではない。

採用、利用、提出、実行は
Execution Entity の責任とする。

publish rules

purpose

Define the conditions for moving from draft to published.

⸻

states
	•	drafts
	•	In creation
	•	published
	•	Ready for publication
	•	archive
	•	Old versions, replaced, or retained for storage

⸻

publish conditions

The following are required to move to published:
	•	Satisfies masking rules
	•	Satisfies validation rules
	•	All required fields (as defined by module requirements) are filled
	•	The content is self-contained and understandable without external context
	•	Prohibited use cases are explicitly defined
	•	Warnings are explicitly defined
	•	module_id is present
	•	version_id is present
	•	content_hash is present
	•	signature is present

⸻

archive conditions

The following are moved to archive:
	•	Replaced by a new version
	•	Risk has been identified
	•	Not used in current operation
	•	Retained for historical record

⸻

note

Publication does not imply any guarantee of usability or safety.

Adoption, use, submission, and execution
are the sole responsibility of the Execution Entity.