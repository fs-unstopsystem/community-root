# masking rules

## purpose

共有してはいけない情報を外し、
共有してよい構造だけを残す。

## hide

次は共有しない。

- 固有名詞
- 個別紛争の詳細
- 法務相談の中身
- 医療、家族、金銭の具体事情
- 連絡先、住所、番号
- 感情履歴
- 生の音声、画像、原文で特定につながるもの

## keep

次は共有してよい。

- モジュール種別
- 入力
- 出力
- 制約
- 禁止用途
- 警告
- 評価基準
- タグ
- バージョン
- ハッシュ
- 署名

## rule

共有前に必ず次を行う。

1. 固有名詞を外す
2. 個別事情を抽象化する
3. 構造だけにする
4. 再特定されないか見る

## result

公開対象は、
「誰の話か」ではなく
「どういう部品か」が分かる状態にする。

masking rules

purpose

Remove information that must not be shared,
and retain only structures that can be shared.

⸻

hide

The following must not be shared:
	•	Proper nouns
	•	Details of individual disputes
	•	Contents of legal consultations
	•	Specific circumstances related to medical, family, or financial matters
	•	Contact information, addresses, and identifiers
	•	Emotional history
	•	Raw audio, images, or original text that can lead to identification

⸻

keep

The following may be shared:
	•	Module type
	•	Input
	•	Output
	•	Constraints
	•	Prohibited use
	•	Warnings
	•	Evaluation criteria
	•	Tags
	•	Version
	•	Hash
	•	Signature

⸻

rule

Before sharing, always perform the following:
	1.	Remove proper nouns
	2.	Abstract individual circumstances
	3.	Reduce to structure only
	4.	Verify that re-identification is not possible

⸻

result

The published output must indicate
not “whose case it is,”
but “what kind of component it is.”