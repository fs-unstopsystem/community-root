# Freesmith Root

このリポジトリは、Freesmithコミュニティの起点および統治構造を定義する。

---

## これは何か

抽象化された要求を、構造化されたモジュール仕様へ変換する仕組みである。

個別事情を開示することなく、安全に共有・改善・実行できる状態を実現する。

---

## 基本原則

- 個別の事例ではなく、抽象化された要求を扱う  
- 人ではなく構造を基準とする  
- AIは判断主体ではなく補助として用いる  
- 問題と人を分離する  

---

## 社会的意義

本構造は、行動へのアクセスにおける構造的な不平等に対処する。

以下を軽減する：
- 知識格差によって行動できない状態  
- 費用格差によって専門的支援にアクセスできない問題  
- 時間的制約による対応遅延  

以下を解消する：
- 説明してくれる人がいなければ何もできない状態  
- 個別事情の開示を前提とする仕組み  

以下を可能にする：
- 構造化された解決手段への直接アクセス  
- 人依存の仕組みから構造依存の仕組みへの移行  

---

## システム構造

要求提示者  
↓  
要求変換機構  
↓  
中間検証層  
↓  
開発コミュニティ  
↓  
実行主体  

---

## このリポジトリが扱うもの

- 統治文書  
- モジュール仕様  
- 設計差分  
- 構造および運用ルール  

---

## このリポジトリが扱わないもの

- 個別案件  
- 法務、医療、その他の個人的事情  
- 識別可能な情報 
- 感情や交渉の履歴  

---

## リポジトリ構造

- `GOVERNANCE/` → 基本原則および統治ルール  
- `MODULES/` → モジュール仕様  
- `SPECS/` → テンプレート  
- `DIFFS/` → 改善提案  
- `OPS/` → 検証およびマスキングルール  

---

## 責任

採用・改変・利用・提出はすべて実行主体の責任とする。

本構造は判断を行うものではなく、構造を提供するものである。

---

## 最小要件

本構造は最低限、以下を満たす必要がある：

- 要求から仕様への変換  
- 匿名化およびマスキング  
- 分類および整理  
- Gitを用いた共有  

---

## コアステートメント

本構造は、問題と人を分離し、  
構造化された解決手段への直接的なアクセスを提供する。

# Freesmith Root

This repository defines the origin and governing structure of the Freesmith community.

---

## What this is

A system that transforms abstracted requests into structured module specifications.

It enables safe sharing, improvement, and execution without exposing individual context.

---

## Core Principles

- Handle abstracted requests, not individual cases  
- Rely on structure, not individuals  
- Use AI as support, not authority  
- Separate problems from people  

---

## Social Purpose

This system addresses structural inequality in access to action.

It reduces:
- Knowledge gaps that prevent action  
- Financial barriers to professional support  
- Time constraints that delay response  

It eliminates:
- Dependence on others for explanation  
- Systems that require exposing personal situations  

It enables:
- Direct access to structured solutions  
- Transition from human-dependent systems to structure-based systems  

---

## System Structure

Request Initiator  
↓  
Request Transformation System  
↓  
Intermediate Validation Layer  
↓  
Development Community  
↓  
Execution Entity  

---

## What this repository contains

- Governance documents  
- Module specifications  
- Design differences (diffs)  
- Structural and operational rules  

---

## What this repository does NOT contain

- Individual cases  
- Legal, medical, or personal situations  
- Identifiable information  
- Emotional or negotiation history  

---

## Repository Structure

- `GOVERNANCE/` → Core principles and rules  
- `MODULES/` → Module specifications  
- `SPECS/` → Templates  
- `DIFFS/` → Improvement proposals  
- `OPS/` → Validation and masking rules  

---

## Responsibility

All adoption, modification, and execution are the responsibility of the execution entity.

This system provides structure, not authority.

---

## Minimum Scope

The system must support:

- Request → specification transformation  
- Anonymization and masking  
- Categorization  
- Git-based sharing  

---

## Core Statement

This system separates problems from people  
and provides direct access to structured solutions.
