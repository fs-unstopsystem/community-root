Freesmith開発者ガイドライン

⸻

0. 位置づけ

開発コミュニティは「問題を解決する場」ではなく「問題を解決する構造を作る場」である
本コミュニティは、抽象化された要件と設計構造を扱う

⸻

1. 基本思想

・構造を信頼する
・履歴と検証を重視する
・AIは補助的存在である

⸻

2. 原点と共有の分離

共有対象：
・モジュール要件ドキュメント
・設計差分

⸻

3. 責任の所在

・開発主体：設計
・実行主体：利用責任
・AI：責任を持たない

・要求提示者：要求を提示するのみ

⸻

4. 匿名性

匿名は許可される
ただし履歴は残る

⸻

5. 共有ルール

投稿は抽象化された設計情報に限定される

⸻

6. DB原則

生成プロセスを記録し、比較可能にする

⸻

7. 禁止事項

・個別事例の共有
・識別可能な情報
・法務、医療、家庭、または金銭に関する事項
・交渉履歴、感情履歴

⸻

8. 推奨

・差分で提示する
・小さく試す

⸻

9. 役割

構造改善のみを行う

⸻

10. 最終原則

共有されるのは事例ではなく、設計差分である

Discord Developer Guidelines

⸻

0. Positioning

The development community is not a place to solve problems, but a place to construct structures that solve problems.
This community handles abstracted requirements and design structures.

⸻

1. Principles
	•	Trust structure
	•	Emphasize history and verification
	•	AI is an auxiliary entity

⸻

2. Separation of Origin and Sharing

Shared objects:
	•	Module requirement documents
	•	Design differences

⸻

3. Responsibility Allocation
	•	Development entity: design
	•	Execution entity: use responsibility
	•	AI: shall not bear responsibility
	•	Request presenter: request presentation only

⸻

4. Anonymity

Anonymity shall be permitted.
However, history shall remain.

⸻

5. Sharing Rules

Posts shall be limited to abstracted design information.

⸻

6. DB Principles

The generation process shall be recorded and made comparable.

⸻

7. Prohibited Matters
	•	Sharing of individual cases
	•	Sharing of identifiable information
	•	Sharing of legal, medical, family, or financial matters
	•	Sharing of negotiation history or emotional history

⸻

8. Recommendations
	•	Present by differences
	•	Try on a small scale

⸻

9. Role

Perform structural improvement only.

⸻

10. Final Principle

What is shared is not cases, but design differences.
