# module requirement template

## purpose

モジュールを書く時の最小ルール。

モジュールは
「今回の話」ではなく
「あとでも使える部品」として書く。

## required

必須項目はこれだけ。

- category
- domain
- module_id
- version_id
- content_hash
- signature

## recommended

あるとよい項目。

- title
- purpose
- input
- output
- constraints
- prohibited_use
- warnings
- tags_local
- tags_mapped

## writing rule

- 一目で役割が分かる名前にする
- 個別事情を書かない
- 何を入れて何が出るか書く
- 危険な使い方を書かない
- タグを付ける
- 別用途で流用できる単位で切る

module requirement template

purpose

Define the minimum required rules for writing modules.

A module must be written
not as a specific, one-off case,
but as a reusable component.

⸻

required

The following are the only mandatory fields:
	•	category
	•	domain
	•	module_id
	•	version_id
	•	content_hash
	•	signature

⸻

recommended

The following fields are recommended:
	•	title
	•	purpose
	•	input
	•	output
	•	constraints
	•	prohibited_use
	•	warnings
	•	tags_local
	•	tags_mapped

⸻

writing rules
	•	Use a name that clearly conveys the module’s role at a glance
	•	Avoid case-specific or context-dependent details
	•	Explicitly define what goes in and what comes out
	•	Exclude unsafe or dangerous usage patterns
	•	Assign tags for classification, searchability, and reuse
	•	Define modules at a granularity that ensures reuse across different contexts
