category: "classification"
domain: "work-log"

module_id: "liner-sorting"
version_id: "v1"
content_hash: ""
signature: ""

title: "liner sorting"
purpose: "thickness and material based sorting"

input:
  - "mixed liner parts"

output:
  - "sorted groups"

constraints:
  - "magnet test required"
  - "thickness must be measured"

prohibited_use:
  - "do not treat uncertain material as fixed"

warnings:
  - "mixed storage causes misclassification"

tags_local:
  - "sorting"
  - "liner"
  - "measurement"

tags_mapped:
  - "classification"
  - "material-check"