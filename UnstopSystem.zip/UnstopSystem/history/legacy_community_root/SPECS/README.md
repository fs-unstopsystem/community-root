# SPECS

このフォルダは部品の書き方を置く場所。

ここで大事なのは、
難しい説明ではなく、
あとで再利用できる形で書くこと。

## purpose

- 部品を同じ型で書く
- 枝で整理できるようにする
- タグで横断検索できるようにする
- 少し変えれば別用途にも流用できるようにする

## basic idea

枝は置き場所。
タグは横断検索。

つまり、

- 枝で大分類する
- タグで再利用する

という考え方で書く。

## file

- module-requirement-template.md
  - 部品を書く時の最小テンプレ

SPECS

purpose

This folder defines how to write components.

The key is not complex explanations,
but writing in a form that can be reused later.

⸻

purpose (details)
	•	Write components in a consistent format
	•	Enable hierarchical organization (by branches)
	•	Enable cross-search using tags
	•	Allow reuse for other purposes with minimal modification

⸻

basic idea

Branches define placement.
Tags enable cross-search.

In other words:
	•	Use branches for classification
	•	Use tags for reuse

⸻

files
	•	module-requirement-template.md
	•	Minimal template for writing components
